"""Explainability module for speech emotion recognition."""
