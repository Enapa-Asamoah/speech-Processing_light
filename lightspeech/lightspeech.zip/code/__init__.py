"""
LightSpeech: Lightweight Emotion Recognition
Source code package
"""

__version__ = "1.0.0"

